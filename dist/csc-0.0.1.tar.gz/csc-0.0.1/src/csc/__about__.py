# SPDX-FileCopyrightText: 2024-present YanisGomes <yanis.gomes@ens-paris-saclay.fr>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
